import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { delay } from 'rxjs/operators';
import { Booking, BookingRequest, BookingStatus } from '../models/booking.model';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class BookingService {
  private mockBookings: Booking[] = [
    {
      id: 1,
      propertyId: 1,
      userId: 2,
      date: new Date('2023-07-20'),
      time: '10:00 AM',
      status: BookingStatus.CONFIRMED,
      notes: 'Looking forward to seeing the property',
      createdAt: new Date('2023-07-10'),
      updatedAt: new Date('2023-07-12')
    },
    {
      id: 2,
      propertyId: 3,
      userId: 2,
      date: new Date('2023-07-25'),
      time: '2:30 PM',
      status: BookingStatus.PENDING,
      notes: 'Interested in the backyard space',
      createdAt: new Date('2023-07-15'),
      updatedAt: new Date('2023-07-15')
    },
    {
      id: 3,
      propertyId: 2,
      userId: 3,
      date: new Date('2023-07-18'),
      time: '3:00 PM',
      status: BookingStatus.COMPLETED,
      createdAt: new Date('2023-07-05'),
      updatedAt: new Date('2023-07-19')
    }
  ];

  constructor(private authService: AuthService) { }

  getAllBookings(): Observable<Booking[]> {
    // Only admin should access all bookings
    if (!this.authService.isAdmin()) {
      return throwError(() => new Error('Unauthorized'));
    }
    return of(this.mockBookings).pipe(delay(500));
  }

  getUserBookings(): Observable<Booking[]> {
    const currentUser = this.authService.getCurrentUser();
    
    if (!currentUser) {
      return throwError(() => new Error('User not logged in'));
    }
    
    const userBookings = this.mockBookings.filter(booking => booking.userId === currentUser.id);
    return of(userBookings).pipe(delay(500));
  }

  getBookingById(id: number): Observable<Booking | undefined> {
    const currentUser = this.authService.getCurrentUser();
    
    if (!currentUser) {
      return throwError(() => new Error('User not logged in'));
    }
    
    const booking = this.mockBookings.find(b => b.id === id);
    
    if (!booking) {
      return of(undefined).pipe(delay(500));
    }
    
    // Check if user is admin or the booking belongs to the user
    if (!this.authService.isAdmin() && booking.userId !== currentUser.id) {
      return throwError(() => new Error('Unauthorized'));
    }
    
    return of(booking).pipe(delay(500));
  }

  createBooking(bookingRequest: BookingRequest): Observable<Booking> {
    const currentUser = this.authService.getCurrentUser();
    
    if (!currentUser) {
      return throwError(() => new Error('User not logged in'));
    }
    
    const newBooking: Booking = {
      id: this.getNextId(),
      propertyId: bookingRequest.propertyId,
      userId: currentUser.id,
      date: bookingRequest.date,
      time: bookingRequest.time,
      status: BookingStatus.PENDING,
      notes: bookingRequest.notes,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    this.mockBookings.push(newBooking);
    return of(newBooking).pipe(delay(500));
  }

  updateBookingStatus(id: number, status: BookingStatus): Observable<Booking | undefined> {
    // Only admin can update booking status
    if (!this.authService.isAdmin() && !this.authService.isAgent()) {
      return throwError(() => new Error('Unauthorized'));
    }
    
    const index = this.mockBookings.findIndex(b => b.id === id);
    
    if (index === -1) {
      return throwError(() => new Error('Booking not found'));
    }
    
    this.mockBookings[index] = {
      ...this.mockBookings[index],
      status,
      updatedAt: new Date()
    };
    
    return of(this.mockBookings[index]).pipe(delay(500));
  }

  cancelBooking(id: number): Observable<boolean> {
    const currentUser = this.authService.getCurrentUser();
    
    if (!currentUser) {
      return throwError(() => new Error('User not logged in'));
    }
    
    const booking = this.mockBookings.find(b => b.id === id);
    
    if (!booking) {
      return throwError(() => new Error('Booking not found'));
    }
    
    // Check if user is admin or the booking belongs to the user
    if (!this.authService.isAdmin() && booking.userId !== currentUser.id) {
      return throwError(() => new Error('Unauthorized'));
    }
    
    // Update booking status to cancelled
    booking.status = BookingStatus.CANCELLED;
    booking.updatedAt = new Date();
    
    return of(true).pipe(delay(500));
  }

  getPropertyBookings(propertyId: number): Observable<Booking[]> {
    // Only admin or agent should access property bookings
    if (!this.authService.isAdmin() && !this.authService.isAgent()) {
      return throwError(() => new Error('Unauthorized'));
    }
    
    const propertyBookings = this.mockBookings.filter(booking => booking.propertyId === propertyId);
    return of(propertyBookings).pipe(delay(500));
  }

  private getNextId(): number {
    return Math.max(...this.mockBookings.map(booking => booking.id), 0) + 1;
  }
}