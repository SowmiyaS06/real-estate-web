import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { delay } from 'rxjs/operators';
import { 
  User, 
  UserRole, 
  AuthResponse, 
  LoginRequest,
  RegisterRequest 
} from '../models/user.model';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private readonly STORAGE_KEY = 'real_estate_auth';
  private mockUsers: User[] = [
    {
      id: 1,
      firstName: 'Admin',
      lastName: 'User',
      email: 'admin@example.com',
      phone: '555-123-4567',
      role: UserRole.ADMIN,
      createdAt: new Date('2023-01-01'),
      updatedAt: new Date('2023-01-01')
    },
    {
      id: 2,
      firstName: 'John',
      lastName: 'Doe',
      email: 'john@example.com',
      phone: '555-987-6543',
      role: UserRole.CLIENT,
      createdAt: new Date('2023-02-15'),
      updatedAt: new Date('2023-02-15')
    },
    {
      id: 3,
      firstName: 'Jane',
      lastName: 'Smith',
      email: 'jane@example.com',
      phone: '555-567-8901',
      role: UserRole.AGENT,
      createdAt: new Date('2023-03-10'),
      updatedAt: new Date('2023-03-10')
    }
  ];

  constructor() { }

  login(request: LoginRequest): Observable<AuthResponse> {
    // Mock implementation - in a real app, this would make an API call
    if (request.email === 'admin@example.com' && request.password === 'password') {
      const user = this.mockUsers.find(u => u.email === request.email);
      if (user) {
        const response: AuthResponse = {
          user,
          token: 'mock-jwt-token-' + Math.random().toString(36).substring(2)
        };
        this.saveAuthData(response);
        return of(response).pipe(delay(800));
      }
    }
    
    return throwError(() => new Error('Invalid email or password'));
  }

  register(request: RegisterRequest): Observable<AuthResponse> {
    // Check if email already exists
    if (this.mockUsers.some(user => user.email === request.email)) {
      return throwError(() => new Error('Email already in use'));
    }

    // Create new user
    const newUser: User = {
      id: this.getNextId(),
      firstName: request.firstName,
      lastName: request.lastName,
      email: request.email,
      phone: request.phone,
      role: UserRole.CLIENT, // Default role for new registrations
      createdAt: new Date(),
      updatedAt: new Date()
    };

    this.mockUsers.push(newUser);

    const response: AuthResponse = {
      user: newUser,
      token: 'mock-jwt-token-' + Math.random().toString(36).substring(2)
    };

    this.saveAuthData(response);
    return of(response).pipe(delay(800));
  }

  logout(): void {
    localStorage.removeItem(this.STORAGE_KEY);
  }

  getCurrentUser(): User | null {
    const authData = this.getAuthData();
    return authData ? authData.user : null;
  }

  isLoggedIn(): boolean {
    return !!this.getCurrentUser();
  }

  getToken(): string | null {
    const authData = this.getAuthData();
    return authData ? authData.token : null;
  }

  hasRole(role: UserRole): boolean {
    const user = this.getCurrentUser();
    return user ? user.role === role : false;
  }

  isAdmin(): boolean {
    return this.hasRole(UserRole.ADMIN);
  }

  isAgent(): boolean {
    return this.hasRole(UserRole.AGENT) || this.isAdmin();
  }

  private saveAuthData(authData: AuthResponse): void {
    localStorage.setItem(this.STORAGE_KEY, JSON.stringify(authData));
  }

  private getAuthData(): AuthResponse | null {
    const data = localStorage.getItem(this.STORAGE_KEY);
    return data ? JSON.parse(data) : null;
  }

  private getNextId(): number {
    return Math.max(...this.mockUsers.map(user => user.id), 0) + 1;
  }
}