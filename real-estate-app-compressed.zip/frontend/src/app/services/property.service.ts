import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { delay } from 'rxjs/operators';
import { Property, PropertyStatus, PropertyType } from '../models/property.model';

@Injectable({
  providedIn: 'root'
})
export class PropertyService {
  private mockProperties: Property[] = [
    {
      id: 1,
      title: 'Modern Beachfront Villa',
      description: 'Stunning beachfront villa with panoramic ocean views, featuring 4 bedrooms, a private pool, and direct beach access. This luxurious property combines contemporary design with comfortable living spaces.',
      price: 1200000,
      type: PropertyType.HOUSE,
      status: PropertyStatus.FOR_SALE,
      location: 'Miami, FL',
      address: '123 Ocean Drive, Miami, FL 33139',
      bedrooms: 4,
      bathrooms: 3.5,
      area: 3200,
      features: ['Ocean View', 'Private Pool', 'Beach Access', 'Smart Home', 'Garage', 'Security System'],
      images: [
        'https://images.pexels.com/photos/1732414/pexels-photo-1732414.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
        'https://images.pexels.com/photos/1643383/pexels-photo-1643383.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
        'https://images.pexels.com/photos/2121121/pexels-photo-2121121.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
      ],
      virtualTourUrl: 'https://example.com/virtual-tour/123',
      videoUrl: 'https://example.com/video/123',
      createdAt: new Date('2023-01-10'),
      updatedAt: new Date('2023-02-15')
    },
    {
      id: 2,
      title: 'Downtown Luxury Apartment',
      description: 'High-end apartment in the heart of the city with stunning skyline views. This unit features premium finishes, an open floor plan, and access to exclusive building amenities.',
      price: 750000,
      type: PropertyType.APARTMENT,
      status: PropertyStatus.FOR_SALE,
      location: 'New York, NY',
      address: '456 Park Avenue, New York, NY 10022',
      bedrooms: 2,
      bathrooms: 2,
      area: 1400,
      features: ['City View', 'Doorman', 'Gym', 'Rooftop Terrace', 'Concierge', 'Pet Friendly'],
      images: [
        'https://images.pexels.com/photos/1918291/pexels-photo-1918291.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
        'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
        'https://images.pexels.com/photos/276724/pexels-photo-276724.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
      ],
      virtualTourUrl: 'https://example.com/virtual-tour/456',
      videoUrl: 'https://example.com/video/456',
      createdAt: new Date('2023-03-05'),
      updatedAt: new Date('2023-03-20')
    },
    {
      id: 3,
      title: 'Suburban Family Home',
      description: 'Spacious family home in a quiet suburban neighborhood with excellent schools. Features include a large backyard, updated kitchen, and finished basement.',
      price: 550000,
      type: PropertyType.HOUSE,
      status: PropertyStatus.FOR_SALE,
      location: 'Austin, TX',
      address: '789 Maple Street, Austin, TX 78701',
      bedrooms: 4,
      bathrooms: 2.5,
      area: 2800,
      features: ['Backyard', 'Garage', 'Fireplace', 'Basement', 'Patio', 'Updated Kitchen'],
      images: [
        'https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
        'https://images.pexels.com/photos/259588/pexels-photo-259588.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
        'https://images.pexels.com/photos/1396122/pexels-photo-1396122.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
      ],
      virtualTourUrl: 'https://example.com/virtual-tour/789',
      videoUrl: 'https://example.com/video/789',
      createdAt: new Date('2023-02-20'),
      updatedAt: new Date('2023-04-01')
    },
    {
      id: 4,
      title: 'Luxury Condo with Ocean View',
      description: 'Breathtaking oceanfront condo with high-end finishes and panoramic views. Featuring an open floor plan, gourmet kitchen, and large terrace.',
      price: 3200,
      type: PropertyType.CONDO,
      status: PropertyStatus.FOR_RENT,
      location: 'San Diego, CA',
      address: '101 Coast Boulevard, San Diego, CA 92109',
      bedrooms: 3,
      bathrooms: 2,
      area: 1800,
      features: ['Ocean View', 'Pool', 'Fitness Center', 'Parking', 'Security', 'Balcony'],
      images: [
        'https://images.pexels.com/photos/1643384/pexels-photo-1643384.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
        'https://images.pexels.com/photos/1669799/pexels-photo-1669799.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
        'https://images.pexels.com/photos/1464625/pexels-photo-1464625.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
      ],
      virtualTourUrl: 'https://example.com/virtual-tour/101',
      videoUrl: 'https://example.com/video/101',
      createdAt: new Date('2023-05-10'),
      updatedAt: new Date('2023-05-25')
    },
    {
      id: 5,
      title: 'Modern Townhouse in Uptown',
      description: 'Stylish townhouse in vibrant neighborhood with rooftop terrace and city views. Featuring contemporary design, high ceilings, and premium fixtures.',
      price: 425000,
      type: PropertyType.TOWNHOUSE,
      status: PropertyStatus.FOR_SALE,
      location: 'Chicago, IL',
      address: '234 Lincoln Avenue, Chicago, IL 60614',
      bedrooms: 3,
      bathrooms: 2.5,
      area: 2000,
      features: ['Rooftop Terrace', 'Hardwood Floors', 'Garage', 'Fireplace', 'Smart Home', 'Energy Efficient'],
      images: [
        'https://images.pexels.com/photos/323780/pexels-photo-323780.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
        'https://images.pexels.com/photos/1029599/pexels-photo-1029599.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
        'https://images.pexels.com/photos/2102587/pexels-photo-2102587.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
      ],
      virtualTourUrl: 'https://example.com/virtual-tour/234',
      videoUrl: 'https://example.com/video/234',
      createdAt: new Date('2023-04-15'),
      updatedAt: new Date('2023-05-10')
    },
    {
      id: 6,
      title: 'Commercial Office Space',
      description: 'Prime commercial office space in downtown business district. Open floor plan with modern amenities and excellent location for businesses.',
      price: 875000,
      type: PropertyType.COMMERCIAL,
      status: PropertyStatus.FOR_SALE,
      location: 'Seattle, WA',
      address: '567 Business Center, Seattle, WA 98101',
      bedrooms: 0,
      bathrooms: 2,
      area: 2500,
      features: ['Reception Area', 'Conference Rooms', 'Kitchenette', 'Parking', 'Security System', 'Central Location'],
      images: [
        'https://images.pexels.com/photos/1098982/pexels-photo-1098982.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
        'https://images.pexels.com/photos/1170412/pexels-photo-1170412.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
        'https://images.pexels.com/photos/260689/pexels-photo-260689.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
      ],
      virtualTourUrl: 'https://example.com/virtual-tour/567',
      videoUrl: 'https://example.com/video/567',
      createdAt: new Date('2023-03-01'),
      updatedAt: new Date('2023-04-15')
    }
  ];

  constructor() { }

  getAllProperties(): Observable<Property[]> {
    return of(this.mockProperties).pipe(delay(500));
  }

  getPropertyById(id: number): Observable<Property | undefined> {
    const property = this.mockProperties.find(prop => prop.id === id);
    return of(property).pipe(delay(500));
  }

  searchProperties(
    query?: string,
    type?: PropertyType,
    status?: PropertyStatus,
    minPrice?: number,
    maxPrice?: number,
    location?: string,
    bedrooms?: number
  ): Observable<Property[]> {
    let filteredProperties = [...this.mockProperties];

    if (query) {
      const lowerQuery = query.toLowerCase();
      filteredProperties = filteredProperties.filter(
        property => property.title.toLowerCase().includes(lowerQuery) ||
                    property.description.toLowerCase().includes(lowerQuery) ||
                    property.location.toLowerCase().includes(lowerQuery)
      );
    }

    if (type) {
      filteredProperties = filteredProperties.filter(property => property.type === type);
    }

    if (status) {
      filteredProperties = filteredProperties.filter(property => property.status === status);
    }

    if (minPrice) {
      filteredProperties = filteredProperties.filter(property => property.price >= minPrice);
    }

    if (maxPrice) {
      filteredProperties = filteredProperties.filter(property => property.price <= maxPrice);
    }

    if (location) {
      const lowerLocation = location.toLowerCase();
      filteredProperties = filteredProperties.filter(
        property => property.location.toLowerCase().includes(lowerLocation)
      );
    }

    if (bedrooms) {
      filteredProperties = filteredProperties.filter(property => property.bedrooms >= bedrooms);
    }

    return of(filteredProperties).pipe(delay(500));
  }

  addProperty(property: Omit<Property, 'id' | 'createdAt' | 'updatedAt'>): Observable<Property> {
    const newProperty: Property = {
      ...property,
      id: this.getNextId(),
      createdAt: new Date(),
      updatedAt: new Date()
    };

    this.mockProperties.push(newProperty);
    return of(newProperty).pipe(delay(500));
  }

  updateProperty(id: number, property: Partial<Property>): Observable<Property | undefined> {
    const index = this.mockProperties.findIndex(prop => prop.id === id);
    if (index !== -1) {
      this.mockProperties[index] = {
        ...this.mockProperties[index],
        ...property,
        updatedAt: new Date()
      };
      return of(this.mockProperties[index]).pipe(delay(500));
    }
    return of(undefined).pipe(delay(500));
  }

  deleteProperty(id: number): Observable<boolean> {
    const initialLength = this.mockProperties.length;
    this.mockProperties = this.mockProperties.filter(property => property.id !== id);
    return of(initialLength > this.mockProperties.length).pipe(delay(500));
  }

  private getNextId(): number {
    return Math.max(...this.mockProperties.map(property => property.id), 0) + 1;
  }

  getFeaturedProperties(count: number = 3): Observable<Property[]> {
    const featured = [...this.mockProperties]
      .sort(() => 0.5 - Math.random())
      .slice(0, count);
    
    return of(featured).pipe(delay(500));
  }
}