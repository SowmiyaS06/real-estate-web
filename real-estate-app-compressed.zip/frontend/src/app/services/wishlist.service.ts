import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { delay } from 'rxjs/operators';
import { Property } from '../models/property.model';
import { AuthService } from './auth.service';
import { PropertyService } from './property.service';

@Injectable({
  providedIn: 'root'
})
export class WishlistService {
  private readonly STORAGE_KEY = 'real_estate_wishlist_';
  
  constructor(
    private authService: AuthService,
    private propertyService: PropertyService
  ) { }

  getWishlist(): Observable<Property[]> {
    const currentUser = this.authService.getCurrentUser();
    
    if (!currentUser) {
      return throwError(() => new Error('User not logged in'));
    }
    
    const wishlistIds = this.getWishlistIds(currentUser.id);
    
    if (wishlistIds.length === 0) {
      return of([]);
    }
    
    return new Observable<Property[]>(observer => {
      this.propertyService.getAllProperties().subscribe({
        next: (properties) => {
          const wishlistProperties = properties.filter(property => 
            wishlistIds.includes(property.id)
          );
          observer.next(wishlistProperties);
          observer.complete();
        },
        error: (error) => {
          observer.error(error);
        }
      });
    }).pipe(delay(300));
  }

  addToWishlist(propertyId: number): Observable<boolean> {
    const currentUser = this.authService.getCurrentUser();
    
    if (!currentUser) {
      return throwError(() => new Error('User not logged in'));
    }
    
    const wishlistIds = this.getWishlistIds(currentUser.id);
    
    if (!wishlistIds.includes(propertyId)) {
      wishlistIds.push(propertyId);
      this.saveWishlistIds(currentUser.id, wishlistIds);
    }
    
    return of(true).pipe(delay(300));
  }

  removeFromWishlist(propertyId: number): Observable<boolean> {
    const currentUser = this.authService.getCurrentUser();
    
    if (!currentUser) {
      return throwError(() => new Error('User not logged in'));
    }
    
    let wishlistIds = this.getWishlistIds(currentUser.id);
    
    wishlistIds = wishlistIds.filter(id => id !== propertyId);
    this.saveWishlistIds(currentUser.id, wishlistIds);
    
    return of(true).pipe(delay(300));
  }

  isInWishlist(propertyId: number): Observable<boolean> {
    const currentUser = this.authService.getCurrentUser();
    
    if (!currentUser) {
      return of(false);
    }
    
    const wishlistIds = this.getWishlistIds(currentUser.id);
    return of(wishlistIds.includes(propertyId));
  }

  private getWishlistIds(userId: number): number[] {
    const storageKey = `${this.STORAGE_KEY}${userId}`;
    const storedIds = localStorage.getItem(storageKey);
    return storedIds ? JSON.parse(storedIds) : [];
  }

  private saveWishlistIds(userId: number, ids: number[]): void {
    const storageKey = `${this.STORAGE_KEY}${userId}`;
    localStorage.setItem(storageKey, JSON.stringify(ids));
  }
}