import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { PropertyService } from '../../services/property.service';
import { Property, PropertyType } from '../../models/property.model';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  featuredProperties: Property[] = [];
  isLoading = true;

  // Property types for search
  propertyTypes = Object.values(PropertyType);

  constructor(private propertyService: PropertyService) {}

  ngOnInit(): void {
    this.loadFeaturedProperties();
  }

  loadFeaturedProperties(): void {
    this.isLoading = true;
    this.propertyService.getFeaturedProperties(6).subscribe({
      next: (properties) => {
        this.featuredProperties = properties;
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Error loading featured properties:', error);
        this.isLoading = false;
      }
    });
  }
}