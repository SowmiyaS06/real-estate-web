import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { Property } from '../../models/property.model';
import { Booking } from '../../models/booking.model';
import { PropertyService } from '../../services/property.service';
import { BookingService } from '../../services/booking.service';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {
  properties: Property[] = [];
  bookings: Booking[] = [];
  loading = {
    properties: true,
    bookings: true
  };
  error = {
    properties: '',
    bookings: ''
  };

  constructor(
    private propertyService: PropertyService,
    private bookingService: BookingService
  ) {}

  ngOnInit() {
    this.loadProperties();
    this.loadBookings();
  }

  loadProperties() {
    this.propertyService.getAllProperties().subscribe({
      next: (properties) => {
        this.properties = properties;
        this.loading.properties = false;
      },
      error: (error) => {
        this.error.properties = 'Failed to load properties';
        this.loading.properties = false;
        console.error('Error loading properties:', error);
      }
    });
  }

  loadBookings() {
    this.bookingService.getAllBookings().subscribe({
      next: (bookings) => {
        this.bookings = bookings;
        this.loading.bookings = false;
      },
      error: (error) => {
        this.error.bookings = 'Failed to load bookings';
        this.loading.bookings = false;
        console.error('Error loading bookings:', error);
      }
    });
  }

  deleteProperty(id: number) {
    if (confirm('Are you sure you want to delete this property?')) {
      this.propertyService.deleteProperty(id).subscribe({
        next: () => {
          this.properties = this.properties.filter(p => p.id !== id);
        },
        error: (error) => {
          console.error('Error deleting property:', error);
          alert('Failed to delete property');
        }
      });
    }
  }
}