import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-virtual-tour',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="container mx-auto p-4">
      <h2 class="text-2xl font-bold mb-4">Virtual Tour</h2>
      <p>Property ID: {{propertyId}}</p>
    </div>
  `,
  styles: [`
    :host {
      display: block;
    }
  `]
})
export class VirtualTourComponent {
  propertyId: string | null = null;

  constructor(private route: ActivatedRoute) {
    this.propertyId = this.route.snapshot.paramMap.get('id');
  }
}