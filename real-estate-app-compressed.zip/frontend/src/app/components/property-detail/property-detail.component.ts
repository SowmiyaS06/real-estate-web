import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { PropertyService } from '../../services/property.service';

@Component({
  selector: 'app-property-detail',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="container mx-auto p-4">
      <h2 class="text-2xl font-bold mb-4">Property Details</h2>
      <p>Property ID: {{propertyId}}</p>
    </div>
  `,
  styles: [`
    :host {
      display: block;
    }
  `]
})
export class PropertyDetailComponent {
  propertyId: string | null = null;

  constructor(
    private route: ActivatedRoute,
    private propertyService: PropertyService
  ) {
    this.propertyId = this.route.snapshot.paramMap.get('id');
  }
}