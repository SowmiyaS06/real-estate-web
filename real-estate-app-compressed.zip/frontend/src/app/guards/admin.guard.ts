import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

export const adminGuard = () => {
  const authService = inject(AuthService);
  const router = inject(Router);

  if (authService.isAdmin()) {
    return true;
  }

  // If logged in but not admin, redirect to home
  if (authService.isLoggedIn()) {
    router.navigate(['/']);
    return false;
  }

  // If not logged in, redirect to login
  router.navigate(['/login'], { queryParams: { returnUrl: router.url } });
  return false;
};