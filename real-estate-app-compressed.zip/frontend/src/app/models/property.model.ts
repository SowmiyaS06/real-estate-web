export interface Property {
  id: number;
  title: string;
  description: string;
  price: number;
  type: PropertyType;
  status: PropertyStatus;
  location: string;
  address: string;
  bedrooms: number;
  bathrooms: number;
  area: number;
  features: string[];
  images: string[];
  virtualTourUrl?: string;
  videoUrl?: string;
  createdAt: Date;
  updatedAt: Date;
}

export enum PropertyType {
  HOUSE = 'House',
  APARTMENT = 'Apartment',
  CONDO = 'Condo',
  TOWNHOUSE = 'Townhouse',
  LAND = 'Land',
  COMMERCIAL = 'Commercial'
}

export enum PropertyStatus {
  FOR_SALE = 'For Sale',
  FOR_RENT = 'For Rent',
  SOLD = 'Sold',
  RENTED = 'Rented'
}