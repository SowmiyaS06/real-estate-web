export interface Booking {
  id: number;
  propertyId: number;
  userId: number;
  date: Date;
  time: string;
  status: BookingStatus;
  notes?: string;
  createdAt: Date;
  updatedAt: Date;
}

export enum BookingStatus {
  PENDING = 'Pending',
  CONFIRMED = 'Confirmed',
  CANCELLED = 'Cancelled',
  COMPLETED = 'Completed'
}

export interface BookingRequest {
  propertyId: number;
  date: Date;
  time: string;
  notes?: string;
}