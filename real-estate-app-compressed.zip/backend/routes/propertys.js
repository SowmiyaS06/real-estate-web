const express = require('express');
const router = express.Router();
const Property = require('../models/property');

// Get all
router.get('/', async (req, res) => {
    const data = await Property.find();
    res.json(data);
});

// Create
router.post('/', async (req, res) => {
    const newItem = new Property(req.body);
    await newItem.save();
    res.json(newItem);
});

module.exports = router;