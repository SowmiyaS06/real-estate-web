const express = require('express');
const router = express.Router();
const Wishlist = require('../models/wishlist');

// Get all
router.get('/', async (req, res) => {
    const data = await Wishlist.find();
    res.json(data);
});

// Create
router.post('/', async (req, res) => {
    const newItem = new Wishlist(req.body);
    await newItem.save();
    res.json(newItem);
});

module.exports = router;