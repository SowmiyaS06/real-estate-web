const express = require('express');
const router = express.Router();
const User = require('../models/user');

// Get all
router.get('/', async (req, res) => {
    const data = await User.find();
    res.json(data);
});

// Create
router.post('/', async (req, res) => {
    const newItem = new User(req.body);
    await newItem.save();
    res.json(newItem);
});

module.exports = router;