const express = require('express');
const router = express.Router();
const Booking = require('../models/booking');

// Get all
router.get('/', async (req, res) => {
    const data = await Booking.find();
    res.json(data);
});

// Create
router.post('/', async (req, res) => {
    const newItem = new Booking(req.body);
    await newItem.save();
    res.json(newItem);
});

module.exports = router;