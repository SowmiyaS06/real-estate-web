const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const BookingSchema = new Schema({
    propertyId: String, userId: String, date: Date
}, { timestamps: true });

module.exports = mongoose.model('Booking', BookingSchema);