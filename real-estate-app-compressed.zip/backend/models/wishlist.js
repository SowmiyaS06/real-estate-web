const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const WishlistSchema = new Schema({
    userId: String, propertyId: String
}, { timestamps: true });

module.exports = mongoose.model('Wishlist', WishlistSchema);